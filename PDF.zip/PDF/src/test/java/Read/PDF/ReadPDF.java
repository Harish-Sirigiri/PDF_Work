package Read.PDF;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.contentstream.PDContentStream;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReadPDF {

	
	public int readJSON() throws IOException {
		ObjectMapper map=new ObjectMapper();
		JsonNode jn=map.readTree(new File("D:\\Files\\sample1.json"));
		int mid=jn.get("id").asInt();
		return mid;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String directoryPath="D:\\Files";
		File directory=new File(directoryPath);
		
		File[] files=directory.listFiles();
		ObjectMapper map=new ObjectMapper();
		/*String JSONfile=".//data/sample1.json";
		JsonNode jn=map.readTree(new File(JSONfile));*/
		ReadPDF rd=new ReadPDF();
		int val=rd.readJSON();
		
		if(val==78435) {
		for (File readfile:files) {
			
			if(readfile.getName().equalsIgnoreCase("Multiple.pdf")) {
			  PDDocument doc=Loader.loadPDF(readfile);
			  int noofpg= doc.getNumberOfPages();
			  PDFRenderer render=new PDFRenderer(doc);
			  BufferedImage img=render.renderImage(0);
			  ImageIO.write(img, "JPEG", new File("D:/Files/myimage.jpg"));
			  PDFTextStripper pdfstripper=new PDFTextStripper();
			  
			  String doctext=pdfstripper.getText(doc);
			  
			  //System.out.println(doctext);
			  System.out.println(noofpg);
			  
			  pdfstripper.setStartPage(1);
			  String sptext=pdfstripper.getText(doc);
			  System.out.println(sptext);
			}
			
			
		}
		
	}
	}

}
